-- Add image_url column to reviews table for screenshot uploads (e.g., SmartStore reviews)
ALTER TABLE reviews ADD COLUMN image_url TEXT;
