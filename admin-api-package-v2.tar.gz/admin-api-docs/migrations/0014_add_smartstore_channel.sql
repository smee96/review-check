-- Add smartstore channel support
ALTER TABLE campaigns ADD COLUMN smartstore_product_url TEXT;
