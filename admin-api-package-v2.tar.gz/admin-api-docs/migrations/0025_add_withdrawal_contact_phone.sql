-- Add contact_phone column to withdrawal_requests table
ALTER TABLE withdrawal_requests ADD COLUMN contact_phone TEXT;
