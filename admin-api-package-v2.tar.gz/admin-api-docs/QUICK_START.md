# 🚀 셀러리 에이전트 개발 빠른 시작 가이드

## 📦 제공된 파일 목록

```
admin-api-docs/
├── README.md                    # 전체 API 문서
├── ENV_SAMPLE.md               # 환경 변수 설정 가이드
├── POSTMAN_COLLECTION.json     # Postman API 테스트 컬렉션
├── QUICK_START.md              # 이 파일
├── admin-routes.ts             # 관리자 라우트 코드
├── campaigns-routes.ts         # 캠페인 라우트 코드
├── applications-routes.ts      # 지원/리뷰 라우트 코드
├── settings-routes.ts          # 시스템 설정 라우트 코드
├── auth-middleware.ts          # 인증 미들웨어
└── migrations/                 # 데이터베이스 스키마
    ├── 0001_initial_schema.sql
    ├── 0002_add_advertiser_profile.sql
    └── ...
```

---

## 🎯 개발 목표

셀러리 에이전트에서 다음 기능을 구현:

1. **캠페인 관리** - 전체 캠페인 조회, 상태 변경, 삭제
2. **리뷰 관리** - 리뷰 조회, 승인/거절
3. **가입자 목록** - 사용자 조회, 상태 관리, 포인트 조정
4. **정산 관리** - 정산 요청 조회, 승인/거절
5. **시스템 설정** - 수수료율, 최소/최대 금액 설정

---

## 🔧 1단계: API 테스트 (Postman 사용)

### Postman 컬렉션 임포트

1. **Postman 열기**
2. **Import** 버튼 클릭
3. **`POSTMAN_COLLECTION.json`** 파일 선택
4. 컬렉션 임포트 완료

### 환경 변수 설정

Postman에서 `baseUrl` 변수 확인:
```
baseUrl: https://fa737302.checknreviews-v1.pages.dev
```

### 첫 API 호출 테스트

1. **로그인 요청**
   ```
   POST /api/auth/login
   Body:
   {
     "email": "admin@example.com",
     "password": "your_password"
   }
   ```

2. **세션 쿠키 자동 저장**
   - Postman이 자동으로 쿠키 저장
   - 이후 요청에 자동 포함

3. **캠페인 목록 조회**
   ```
   GET /api/admin/campaigns?status=all&page=1&limit=20
   ```

---

## 💻 2단계: 코드 구조 이해

### 인증 흐름
```typescript
// auth-middleware.ts 참고
1. 로그인 → 세션 생성 → 쿠키 발급
2. 이후 요청 시 쿠키로 사용자 확인
3. role === 'admin' 체크
```

### API 응답 형식
```typescript
// 성공
{
  "message": "성공 메시지",
  "data": { ... }
}

// 실패
{
  "error": "에러 메시지",
  "details": "상세 정보"
}
```

### 데이터베이스 접근
```typescript
// Cloudflare D1 (SQLite) 사용
const result = await c.env.DB.prepare(`
  SELECT * FROM campaigns WHERE status = ?
`).bind('active').all();
```

---

## 🛠️ 3단계: 셀러리에서 구현하기

### Option A: REST API 호출 방식 (추천)

셀러리에서 HTTP 요청으로 기존 API 호출:

```typescript
// 예시: 캠페인 목록 가져오기
const response = await fetch('https://fa737302.checknreviews-v1.pages.dev/api/admin/campaigns?status=all&page=1&limit=20', {
  method: 'GET',
  headers: {
    'Cookie': 'session=xxx', // 로그인 후 받은 세션 쿠키
  }
});

const data = await response.json();
console.log(data.campaigns);
```

**장점:**
- 기존 API를 그대로 사용
- 코드 중복 없음
- 인증/권한 검증 재사용

---

### Option B: 직접 데이터베이스 접근 방식

셀러리에서 Cloudflare D1에 직접 연결:

```typescript
// wrangler.jsonc에 D1 바인딩 추가
{
  "d1_databases": [
    {
      "binding": "DB",
      "database_name": "checknreviews-v1-production",
      "database_id": "your-database-id"
    }
  ]
}

// 코드에서 직접 쿼리
const campaigns = await env.DB.prepare(`
  SELECT 
    c.*,
    u.nickname as advertiser_nickname,
    COUNT(a.application_id) as application_count
  FROM campaigns c
  LEFT JOIN users u ON c.advertiser_id = u.user_id
  LEFT JOIN applications a ON c.campaign_id = a.campaign_id
  WHERE c.status = ?
  GROUP BY c.campaign_id
`).bind('active').all();
```

**장점:**
- 더 유연한 쿼리 가능
- 성능 최적화 가능

**단점:**
- 코드 중복
- 인증/권한 검증 직접 구현 필요

---

## 📊 4단계: UI 구성 예시

### 대시보드
```
┌─────────────────────────────────────┐
│  체크앤리뷰 관리자 대시보드          │
├─────────────────────────────────────┤
│  📊 오늘 방문자: 150명               │
│  👥 전체 사용자: 1,234명             │
│  📢 전체 캠페인: 56개                │
│  ⭐ 리뷰 대기: 12건                  │
│  💰 정산 대기: 5건                   │
└─────────────────────────────────────┘
```

### 캠페인 목록
```
┌─────────────────────────────────────────────────┐
│  캠페인 관리                                     │
├──────┬──────────┬────────┬────────┬──────────┤
│ ID   │ 제목      │ 광고주  │ 상태    │ 액션      │
├──────┼──────────┼────────┼────────┼──────────┤
│ 1    │ 신제품... │ 광고주A │ active  │ [상세][삭제]│
│ 2    │ 이벤트... │ 광고주B │ pending │ [승인][거절]│
└──────┴──────────┴────────┴────────┴──────────┘
```

---

## 🔍 5단계: 주요 기능별 API 매핑

### 캠페인 관리
```
✅ 목록 조회: GET /api/admin/campaigns
✅ 상세 보기: GET /api/campaigns/:id
✅ 상태 변경: PUT /api/admin/campaigns/:id/status
✅ 삭제: DELETE /api/admin/campaigns/:id
```

### 리뷰 관리
```
✅ 목록 조회: GET /api/admin/reviews
✅ 승인/거절: PUT /api/admin/reviews/:id/status
```

### 가입자 관리
```
✅ 목록 조회: GET /api/admin/users
✅ 상세 보기: GET /api/admin/users/:id
✅ 상태 변경: PUT /api/admin/users/:id/status
✅ 포인트 조정: POST /api/admin/users/:id/points
```

### 정산 관리
```
✅ 목록 조회: GET /api/admin/settlements
✅ 승인/거절: PUT /api/admin/settlements/:id/status
✅ CSV 다운로드: GET /api/admin/settlements/export
```

### 시스템 설정
```
✅ 설정 조회: GET /api/admin/settings
✅ 설정 변경: PUT /api/admin/settings/:key
```

---

## 🧪 6단계: 테스트 시나리오

### 1. 로그인 테스트
```bash
curl -X POST https://fa737302.checknreviews-v1.pages.dev/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@example.com","password":"your_password"}' \
  -c cookies.txt
```

### 2. 캠페인 목록 조회
```bash
curl -X GET https://fa737302.checknreviews-v1.pages.dev/api/admin/campaigns \
  -b cookies.txt
```

### 3. 캠페인 승인
```bash
curl -X PUT https://fa737302.checknreviews-v1.pages.dev/api/admin/campaigns/1/status \
  -H "Content-Type: application/json" \
  -d '{"status":"active"}' \
  -b cookies.txt
```

---

## 📚 7단계: 추가 참고 자료

### README.md
- 전체 API 엔드포인트 문서
- 요청/응답 예시
- 데이터베이스 스키마

### ENV_SAMPLE.md
- 환경 변수 설정
- 관리자 계정 생성 방법
- 데이터베이스 초기화

### 소스 코드 파일
- `admin-routes.ts`: 관리자 API 구현 코드
- `campaigns-routes.ts`: 캠페인 API 구현 코드
- `auth-middleware.ts`: 인증 로직

### 마이그레이션 파일
- `migrations/*.sql`: 데이터베이스 스키마 정의

---

## 🎯 추천 개발 순서

1. **Postman으로 API 테스트** (30분)
   - 모든 엔드포인트 호출 테스트
   - 응답 구조 확인

2. **대시보드 통계 구현** (1시간)
   - GET /api/admin/stats
   - 간단한 통계 카드 표시

3. **캠페인 목록 구현** (2시간)
   - GET /api/admin/campaigns
   - 테이블 형태로 표시
   - 페이지네이션

4. **캠페인 상세/승인 기능** (2시간)
   - GET /api/campaigns/:id
   - PUT /api/admin/campaigns/:id/status

5. **리뷰 관리 구현** (2시간)
   - 리뷰 목록 조회
   - 승인/거절 기능

6. **가입자 관리 구현** (2시간)
   - 사용자 목록
   - 포인트 조정

7. **정산 관리 구현** (2시간)
   - 정산 요청 목록
   - 승인/거절

8. **시스템 설정 구현** (1시간)
   - 설정 조회/수정

**총 예상 시간: 12-15시간**

---

## 💡 팁 & 주의사항

### 인증 관리
- 로그인 후 세션 쿠키를 안전하게 저장
- 각 요청에 쿠키 자동 포함되도록 설정
- 401 응답 시 재로그인 처리

### 에러 처리
- 모든 API 호출에 try-catch 적용
- 사용자 친화적인 에러 메시지 표시
- 네트워크 오류 재시도 로직

### 성능 최적화
- 목록 데이터는 페이지네이션 필수
- 불필요한 API 호출 최소화
- 로딩 상태 표시

### 보안
- 관리자 권한 확인
- XSS 방지 (사용자 입력 검증)
- CSRF 토큰 (필요시)

---

## 🆘 문제 발생 시

### API 호출 실패
1. 세션 쿠키 확인
2. 관리자 권한 확인
3. 네트워크 연결 확인

### 데이터베이스 오류
1. 마이그레이션 적용 확인
2. 데이터베이스 연결 확인
3. SQL 쿼리 오류 로그 확인

### 배포 문제
1. 환경 변수 설정 확인
2. Cloudflare Pages 로그 확인
3. wrangler.jsonc 설정 확인

---

## 📞 추가 지원

필요한 API가 없거나 수정이 필요하면:
1. GitHub Issues에 요청
2. API 문서 확인 후 직접 구현
3. 기존 코드 참고하여 확장

**행운을 빕니다! 🚀**
